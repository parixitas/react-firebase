import React, { Component } from 'react';
import AuthUserContext from '../auth/AuthUserContext';
import SignOutButton from '../auth/SignOut';
import { SignInWithFacebook } from '../auth/SignIn';
import * as routes from '../../constants/routes';
import './LogoDiceFanaticsIcon.png';

import {
    Navbar,
    NavbarBrand,
    Nav,
    NavItem,
    NavLink,
    UncontrolledDropdown,
    DropdownToggle,
    DropdownMenu,
    DropdownItem,
} from 'reactstrap';
// import { SignupWithFacebook } from '../auth/SignUp';


class Navigation extends Component {
    constructor(props) {
        super(props);

        this.toggle = this.toggle.bind(this);
        this.state = {
            isOpen: true,
        }
    }

    toggle() {
        this.setState({
            isOpen: !this.state.isOpen,
        })
    }

    render() {
        return (
            <Navbar color="light" light expand="md" className="sticky-top">
                <NavbarBrand href={routes.LANDING}></NavbarBrand>
                <AuthUserContext.Consumer>
                    { authUser => authUser
                        ? <NavigationAuth/> 
                        : <NavigationNonAuth/>
                    }
                </AuthUserContext.Consumer>
            </Navbar>
        )
    }
}

const NavigationAuth = () => 
    <Nav className="ml-auto" navbar>
        <NavItem>
            <NavLink href={routes.HOME}>Home</NavLink>
        </NavItem>
        <NavItem>
            <NavLink href={routes.ACCOUNT}>Account</NavLink>
        </NavItem>
        <UncontrolledDropdown nav inNavbar>
            <DropdownToggle nav caret>
                Admin
            </DropdownToggle>
            <DropdownMenu>
                <DropdownItem>
                    <NavLink href={routes.ADMIN}>Dashboard</NavLink>
                </DropdownItem>
                <DropdownItem>
                    <NavLink href={routes.ADMINMANUFACTURERS}>Manufacturers</NavLink>
                </DropdownItem>
                <DropdownItem>
                    <NavLink href={routes.ADMINRETAILERS}>Retailers</NavLink>
                </DropdownItem>
                <DropdownItem>
                    <NavLink href={routes.ADMINCRATES}>Crates</NavLink>
                </DropdownItem>
                <DropdownItem>
                    <NavLink href={routes.ADMINCOLLECTIONS}>Collections</NavLink>
                </DropdownItem>
                <DropdownItem>
                    <NavLink href={routes.ADMINPRODUCTLINES}>Product Lines</NavLink>
                </DropdownItem>
                <DropdownItem>
                    <NavLink href={routes.ADMINSETS}>Sets</NavLink>
                </DropdownItem>
                <DropdownItem>
                    <NavLink href={routes.ADMINSETTYPES}>Set Types</NavLink>
                </DropdownItem>
                <DropdownItem>
                    <NavLink href={routes.ADMINCOLORS}>Colors</NavLink>
                </DropdownItem>
                <DropdownItem>
                    <NavLink href={routes.ADMINCOLORGROUPS}>Color Groups</NavLink>
                </DropdownItem>
                <DropdownItem>
                    <NavLink href={routes.ADMINMATERIALS}>Materials</NavLink>
                </DropdownItem>
                <DropdownItem>
                    <NavLink href={routes.ADMINMATERIALTYPES}>Material Types</NavLink>
                </DropdownItem>                
                <DropdownItem>
                    <NavLink href={routes.ADMINSTYLES}>Styles</NavLink>
                </DropdownItem>
                <DropdownItem>
                    <NavLink href={routes.ADMINSTYLETYPES}>Style Types</NavLink>
                </DropdownItem>
                <DropdownItem>
                    <NavLink href={routes.ADMINSHAPES}>Shapes</NavLink>
                </DropdownItem>
                <DropdownItem>
                    <NavLink href={routes.ADMINUNITOFMEASURES}>Units of Measurement</NavLink>
                </DropdownItem>
                {/* <DropdownItem>
                    <NavLink href={routes.ADMINUSERS}>Users</NavLink>
                </DropdownItem> */}
            </DropdownMenu>
        </UncontrolledDropdown>
        <NavItem>
            <SignOutButton/>
        </NavItem>
    </Nav>
const NavigationNonAuth = () =>
    <Nav className="ml-auto" navbar>
        {/* <NavItem>
            <SignupWithFacebook/>
        </NavItem>
         &nbsp;  */}
        <NavItem>
            <SignInWithFacebook/>
            {/* <NavLink href={routes.SIGN_IN}>Login</NavLink> */}
        </NavItem>
    </Nav>

export default Navigation;