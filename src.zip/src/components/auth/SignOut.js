import React from 'react';
import { auth } from '../../firebase';
import AuthUserContext from './AuthUserContext';
import { Button } from 'reactstrap';

const SignOutButton = () => {
    return (
        <AuthUserContext.Consumer>
            { authUser => authUser 
                ? <Button type="button" onClick={auth.doSignOut}>Sign Out</Button>
                : ''}
            {/* { authUser => authUser 
                ? <button type="button" onClick={auth.doSignOut}>Sign Out {authUser.email}</button>
                : ''} */}
        </AuthUserContext.Consumer>
    )
}
export default SignOutButton;
