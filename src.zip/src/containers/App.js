import React from 'react';
import { BrowserRouter as Router, Route } from 'react-router-dom';
import Navigation from '../components/navigation/Navigation';
import LandingPage from './Landing';
import SignUpPage from '../components/auth/SignUp';
import SignInPage from '../components/auth/SignIn';
import PasswordForgotPage from '../components/auth/PasswordForgot';
import HomePage from './Home';
import AccountPage from './account/Account';

import AdminPage from './admin/Admin';
import Manufacturers from './admin/manufacturer/Manufacturers';
import Retailers from './admin/retailer/Retailers';
import Crates from './admin/crate/Crates';
import Users from './admin/user/Users';
import Collections from './admin/collection/Collections';
import ProductLines from './admin/productLine/ProductLines';
import Sets from './admin/set/Sets';
import SetTypes from './admin/setType/SetTypes';
import Colors from './admin/color/Colors';
import ColorGroups from './admin/colorGroup/ColorGroups';
import Materials from './admin/material/Materials';
import MaterialTypes from './admin/materialType/MaterialTypes';
import Styles from './admin/style/Styles';
import StyleTypes from './admin/styleType/StyleTypes';
import Shapes from './admin/shape/Shapes';
import UnitOfMeasures from './admin/unitOfMeasure/UnitOfMeasures';

import * as routes from '../constants/routes';
import withAuthentication from '../components/auth/withAuthentication';
import { Container, Row, Col, } from 'reactstrap';


const App = () =>
    <Router>
        <div>
            <Navigation/>
            <hr/>
            <Container>
                <Row>
                    <Col>
                        <Route exact path={routes.LANDING} component={LandingPage}/>
                        <Route exact path={routes.SIGN_UP} component={SignUpPage}/>
                        <Route exact path={routes.SIGN_IN} component={SignInPage}/>
                        <Route exact path={routes.PASSWORD_FORGOT} component={PasswordForgotPage}/>
                        <Route exact path={routes.HOME} component={HomePage}/>
                        <Route exact path={routes.ACCOUNT} component={AccountPage}/>
                        <Route exact path={routes.ADMIN} component={AdminPage}/>
                        <Route exact path={routes.ADMINMANUFACTURERS} component={Manufacturers}/>
                        <Route exact path={routes.ADMINRETAILERS} component={Retailers}/>
                        <Route exact path={routes.ADMINCRATES} component={Crates}/>
                        <Route exact path={routes.ADMINUSERS} component={Users}/>
                        <Route exact path={routes.ADMINCOLLECTIONS} component={Collections}/>
                        <Route exact path={routes.ADMINPRODUCTLINES} component={ProductLines}/>
                        <Route exact path={routes.ADMINSETS} component={Sets}/>
                        <Route exact path={routes.ADMINSETTYPES} component={SetTypes}/>
                        <Route exact path={routes.ADMINCOLORS} component={Colors}/>
                        <Route exact path={routes.ADMINMATERIALS} component={Materials}/>
                        <Route exact path={routes.ADMINMATERIALTYPES} component={MaterialTypes}/>
                        <Route exact path={routes.ADMINSTYLES} component={Styles}/>
                        <Route exact path={routes.ADMINSTYLETYPES} component={StyleTypes}/>
                        <Route exact path={routes.ADMINSHAPES} component={Shapes}/>
                        <Route exact path={routes.ADMINCOLORGROUPS} component={ColorGroups}/>
                        <Route exact path={routes.ADMINUNITOFMEASURES} component={UnitOfMeasures}/>
                    </Col>
                </Row>
            </Container>
        </div>
    </Router>


export default withAuthentication(App);