import React, { Component } from 'react';
import ReactTable from 'react-table';
import 'react-table/react-table.css';
import { db } from '../../../firebase';
import AddShape from './AddShape';
import EditShape from './EditShape';
import { Button, Row, Col} from 'reactstrap';
import { FaWindowClose } from 'react-icons//fa';

class ListShapes extends Component {
    constructor() {
        super();
        this.state = {
            data: [],
            types: [],
            geometries: [],
        };
        this.getData = this.getData.bind(this);
        this.removeData = this.removeData.bind(this);
    }

    componentDidMount() {
        this.getData();
        this.getTypes();
        this.getGeometries();
    }

    getData() {
        db.getObjects(this.props.baseObject)
            .then(snapshot => {
                const tempResults = snapshot.val();
                if(tempResults) {
                    // Need to tweak the object to put the key into the data so the firebase ID is accessible
                    const results = Object.entries(tempResults).map(e => Object.assign(e[1], { key: e[0] }));
                    // console.log(results)
                    this.setState({ data: Object.values(results)});
                } else {
                    this.setState({ data: [] });
                }
            });
    }

    getTypes () {
        db.getObjects('Types')
        .then(snapshot => {
            let data = snapshot.val();
            let list = [];
            for(let item in data) {
                list.push({
                    id: item,
                    title: data[item].title,
                })
            }
            this.setState({
                types: list,
            })
        });
    }

    getGeometries () {
        db.getObjects('Geometries')
        .then(snapshot => {
            let data = snapshot.val();
            let list = [];
            for(let item in data) {
                list.push({
                    id: item,
                    title: data[item].title,
                })
            }
            this.setState({
                geometries: list,
            })
        });
    }

    removeData(itemId) {
        db.deleteObject(this.props.baseObject, itemId)
            .then( d => {this.getData();})
    } 
    
    render() {
        const { data } = this.state;
        return (
            <div>
                <ReactTable
                    data={ data }
                    columns={[
                        {
                            Header: () => (
                                <Row>
                                    <Col xs={{ size: 8, offset: 2}}><h2>{this.props.baseObject}</h2></Col>
                                    <Col xs="2" className="text-right">
                                        <AddShape 
                                            buttonLabel="Add" 
                                            color="primary"
                                            modalTitle={`Add New ${this.props.baseObject}`} 
                                            handleRefresh={this.getData} 
                                            types={this.state.types} 
                                            geometries={this.state.geometries}
                                        />
                                    </Col>
                                </Row>
                            ),
                            columns: [
                                {
                                    Header: "Shape",
                                    accessor: "title",
                                },
                                {
                                    Header: "Description",
                                    accessor: "description",
                                },
                                {
                                    Header: "Sides",
                                    accessor: "sides",
                                },
                                {
                                    Header: "Type",
                                    accessor: "type",
                                },  
                                {
                                    Header: "Geometry?",
                                    accessor: "geometry",
                                },
                                {
                                    Header: "Patented?",
                                    accessor: "patentURL",
                                },
                                {
                                    Header: "",
                                    width: 50,
                                    id: "delete",
                                    filterable: false,
                                    Cell: ({original}) => (
                                        <div>
                                            <Button color="secondary" onClick={() => this.removeData(original.key)}> <FaWindowClose /> </Button> 
                                        </div>
                                    )
                                },
                                {
                                    Header: "",
                                    width: 90,
                                    id: "edit",
                                    filterable: false,
                                    Cell: ({original}) => (
                                        <Col className="text-right">
                                            <EditShape 
                                                buttonLabel="Edit" 
                                                modalTitle="Edit Shape" 
                                                dataRow={original} 
                                                uniqueId={original.key} 
                                                handleRefresh={this.getData}  
                                                types={this.state.types} 
                                                geometries={this.state.geometries}/>
                                        </Col>
                                    )
                                },
                            ]
                        }

                    ]}
                    defaultPageSize={10}
                    className="-striped -highlight"
                />
            </div>
        );
    }
}

export default ListShapes;
