import React, { Component } from 'react';
import ReactTable from 'react-table';
import 'react-table/react-table.css';
import { db } from '../../../firebase';
import AddColor from './AddColor';
import EditColor from './EditColor';
import { Button, Row, Col} from 'reactstrap';
import { FaWindowClose } from 'react-icons//fa';

class ListColors extends Component {
    constructor() {
        super();
        this.state = {
            data: [],
            colorGroups: [],
        };
        this.getData = this.getData.bind(this);
        this.removeData = this.removeData.bind(this);
        this.complementaryColor = this.complementaryColor.bind(this);
    }

    componentDidMount() {
        this.getData();
        this.getColorGroups();
    }

    getData() {
        db.getObjects(this.props.baseObject)
            .then(snapshot => {
                const tempResults = snapshot.val();
                if(tempResults) {
                    // Need to tweak the object to put the key into the data so the firebase ID is accessible
                    const results = Object.entries(tempResults).map(e => Object.assign(e[1], { key: e[0] }));
                    // console.log(results)
                    this.setState({ data: Object.values(results)});
                } else {
                    this.setState({ data: [] });
                }
            });
    }

    getColorGroups () {
        db.getObjects('ColorGroups')
        .then(snapshot => {
            let data = snapshot.val();
            let list = [];
            for(let item in data) {
                list.push({
                    id: item,
                    title: data[item].title,
                })
            }
            this.setState({
                colorGroups: list,
            })
        });
    }

    complementaryColor = (color) => {
        const hexColor = color.replace('#', '0x');
        return `#${('000000' + (('0xffffff' ^ hexColor).toString(16))).slice(-6)}`;
    };

    removeData(itemId) {
        db.deleteObject(this.props.baseObject, itemId)
            .then( d => {this.getData();})
    } 
    
    render() {
        const { data } = this.state;
        return (
            <div>
                <ReactTable
                    data={ data }
                    columns={[
                        {
                            Header: () => (
                                <Row>
                                    <Col xs={{ size: 8, offset: 2}}><h2>{this.props.baseObject}</h2></Col>
                                    <Col xs="2" className="text-right">
                                        <AddColor 
                                            buttonLabel="Add" 
                                            modalTitle={`Add New ${this.props.baseObject}`} 
                                            handleRefresh={this.getData} 
                                            colorGroups={this.state.colorGroups} 
                                        />
                                    </Col>
                                </Row>
                            ),
                            columns: [
                                {
                                    Header: "Color",
                                    accessor: "title",
                                },
                                {
                                    Header: "Color Group",
                                    accessor: "colorGroup",
                                },
                                // {
                                //     Header: "Pantone",
                                //     accessor: "pantoneCode",
                                // },
                                // {
                                //     Header: "RGB",
                                //     accessor: "rgbCode",
                                // },  
                                {
                                    Header: 'Color',
                                    accessor: 'hexCode',
                                    Cell: row => (
                                      <div className="text-center"
                                        style={{
                                            border: '1px',
                                            padding: '7px',
                                            width: '100%',
                                            height: '100%',
                                            backgroundColor: `${row.value}`,
                                            borderRadius: '2px',
                                            color: this.complementaryColor(`${row.value}`)
                                        }}
                                      >
                                        {row.value}
                                      </div>
                                    )
                                },
                                {
                                    Header: "",
                                    width: 50,
                                    id: "delete",
                                    filterable: false,
                                    Cell: ({original}) => (
                                        <div>
                                            <Button 
                                                color="secondary" 
                                                onClick={() => this.removeData(original.key)}
                                            > 
                                                <FaWindowClose /> 
                                            </Button> 
                                        </div>
                                    )
                                },
                                {
                                    Header: "",
                                    width: 90,
                                    id: "edit",
                                    filterable: false,
                                    Cell: ({original}) => (
                                        <Col className="text-right">
                                            <EditColor 
                                                buttonLabel="Edit" 
                                                modalTitle="Edit Color" 
                                                dataRow={original} 
                                                uniqueId={original.key} 
                                                handleRefresh={this.getData}  
                                                colorGroups={this.state.colorGroups} 
                                            />
                                        </Col>
                                    )
                                },
                            ]
                        }

                    ]}
                    defaultPageSize={10}
                    className="-striped -highlight"
                />
            </div>
        );
    }
}

export default ListColors;
