import React from 'react';

import AuthUserContext from '../../components/auth/AuthUserContext';
import withAuthorization from '../../components/auth/withAuthorization';

import { Container, Row, Col } from 'reactstrap';


const AdminPage = () =>
    <AuthUserContext.Consumer>
        {authUser =>
            <Container>
                <Row>
                    <Col>
                    <h1>Admin Page</h1>
                    <p>Restricted area to admins only</p>
                    </Col>
                </Row>
            </Container>
        }
    </AuthUserContext.Consumer>


// const authCondition = (authUser) => !!authUser && authUser.role === 'ADMIN';
const authCondition = (authUser) => !!authUser;

export default withAuthorization(authCondition)(AdminPage);